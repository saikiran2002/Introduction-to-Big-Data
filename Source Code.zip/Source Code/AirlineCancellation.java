import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;

public class AirlineCancellationsMapper extends Mapper<Object, Text, Text, IntWritable> {
	
	@Override
	protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {

		String[] information = value.toString().split(",");
		if (!"Year".equals(information[0])) {
			if ("1".equals(information[21]) && !"NA".equals(information[22]) && information[22].trim().length() > 0) {
				context.write(new Text(information[22]), new IntWritable(1));
			}

		}
	}
}

public class AirlineCancellationReducer extends Reducer<Text, IntWritable, Text, Text> {
    private Map<String, Integer> cancellationReasons = new TreeMap<>();

    @Override
    protected void reduce(Text key, Iterable<IntWritable> values, Context context)
            throws IOException, InterruptedException {
        Iterator<IntWritable> iterator = values.iterator();
        int total = 0;
        while (iterator.hasNext()) {
            int count = Integer.parseInt(iterator.next().toString());
            total += count;
        }
        cancellationReasons.put(key.toString(), total);
    }

    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        if (!cancellationReasons.isEmpty()) {
            List<Entry<String, Integer>> sortedList = new ArrayList<>(cancellationReasons.entrySet());
            Collections.sort(sortedList, new Comparator<Map.Entry<String, Integer>>() {
                public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
                    return o2.getValue().compareTo(o1.getValue());
                }
            });
            Entry<String, Integer> mostCommonReason = sortedList.get(0);
            boolean flag = false;
            if ("A".equals(mostCommonReason.getKey())) {
                flag = true;
                context.write(new Text("Most common cancellation reason (Code A: Carrier)"),
                        new Text("Count: " + mostCommonReason.getValue()));
            } else if ("B".equals(mostCommonReason.getKey())) {
                flag = true;
                context.write(new Text("Most common cancellation reason (Code B: Weather)"),
                        new Text("Count: " + mostCommonReason.getValue()));
            } else if ("C".equals(mostCommonReason.getKey())) {
                flag = true;
                context.write(new Text("Most common cancellation reason (Code C: NAS)"),
                        new Text("Count: " + mostCommonReason.getValue()));
            } else if ("D".equals(mostCommonReason.getKey())) {
                flag = true;
                context.write(new Text("Most common cancellation reason (Code D: Security)"),
                        new Text("Count: " + mostCommonReason.getValue()));
            }

            if (!flag) {
                context.write(new Text("There is no most common reason for flight cancellations."), new Text(""));
            }
        } else {
            context.write(new Text("There is no most common reason for flight cancellations."), new Text(""));
        }
    }
}

