import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper;

public class AirlineScheduleMapper extends Mapper<Object, Text, Text, Text> {
    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        String[] information = value.toString().split(",");
        if (!"Year".equals(information[0])) {
            String scheduleStatus = "0";
            if (!"NA".equals(information[14])) {
                int delayMinutes = Integer.parseInt(information[14]);
                if (delayMinutes <= 10) {
                    scheduleStatus = "1";
                }
                context.write(new Text(information[8]), new Text(scheduleStatus));
            }
        }
    }
}

public class AirlineScheduleReducer extends Reducer<Text, Text, Text, Text> {
    private Map<String, Double> scheduleMap = new TreeMap<>();

    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context)
            throws IOException, InterruptedException {
        Iterator<Text> iterator = values.iterator();
        int totalCount = 0;
        double onScheduleCount = 0.0;
        while (iterator.hasNext()) {
            int scheduleStatus = Integer.parseInt(iterator.next().toString());
            onScheduleCount += scheduleStatus;
            totalCount++;
        }
        double result = onScheduleCount / totalCount;
        scheduleMap.put(key.toString(), Double.valueOf(result));
    }

    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        List<Entry<String, Double>> sortedList = new ArrayList<>(scheduleMap.entrySet());
        Collections.sort(sortedList, new Comparator<Map.Entry<String, Double>>() {
            public int compare(Entry<String, Double> o1, Entry<String, Double> o2) {
                return o2.getValue().compareTo(o1.getValue());
            }
        });

        context.write(new Text("Highest On-Time Performance"), new Text(""));
        for (int i = 0; i < Math.min(3, sortedList.size()); i++) {
            Entry<String, Double> entry = sortedList.get(i);
            context.write(new Text(entry.getKey()), new Text(entry.getValue() + ""));
        }

        context.write(new Text("Lowest On-Time Performance"), new Text(""));
        int size = sortedList.size();
        for (int j = size - 1; j >= Math.max(0, size - 3); j--) {
            Entry<String, Double> entry = sortedList.get(j);
            context.write(new Text(entry.getKey()), new Text(entry.getValue() + ""));
        }

        if (size == 0) {
            context.write(new Text("No data available for analysis."), new Text(""));
        }
    }
}

