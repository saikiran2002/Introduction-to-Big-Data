import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper;

public class AirlineTaxiTimeMapper extends Mapper<Object, Text, Text, Text> {
    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        String[] data = value.toString().split(",");
        if (!"Year".equals(data[0])) {
            if (!"NA".equals(data[20])) {
                context.write(new Text(data[16]), new Text(data[20]));
            }
            if (!"NA".equals(data[19])) {
                context.write(new Text(data[17]), new Text(data[19]));
            }
        }
    }
}

public class AirlineTaxiTimeReducer extends Reducer<Text, Text, Text, Text> {
    private Map<String, Double> normalMap = new TreeMap<>();
    private Map<String, Double> exceptionMap = new TreeMap<>();

    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context)
            throws IOException, InterruptedException {
        Iterator<Text> iterator = values.iterator();
        int totalCount = 0;
        int normalCount = 0;

        while (iterator.hasNext()) {
            String temp = iterator.next().toString();
            int value = Integer.parseInt(temp);
            normalCount += value;
            totalCount++;
        }

        double result = normalCount * 1.0 / totalCount;

        if (result == 0.0) {
            exceptionMap.put(key.toString(), result);
        } else {
            normalMap.put(key.toString(), Double.valueOf(result));
        }
    }

    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        if (!normalMap.isEmpty()) {
            List<Entry<String, Double>> sortedList = new ArrayList<>(normalMap.entrySet());
            Collections.sort(sortedList, new Comparator<Map.Entry<String, Double>>() {
                public int compare(Entry<String, Double> o1, Entry<String, Double> o2) {
                    return o2.getValue().compareTo(o1.getValue());
                }
            });

            context.write(new Text("Highest Taxi Time"), new Text(""));
            for (int i = 0; i < Math.min(3, sortedList.size()); i++) {
                Entry<String, Double> entry = sortedList.get(i);
                context.write(new Text(entry.getKey()), new Text(entry.getValue() + ""));
            }

            context.write(new Text("Lowest Taxi Time"), new Text(""));
            int size = sortedList.size();
            for (int j = size - 1; j >= Math.max(0, size - 3); j--) {
                Entry<String, Double> entry = sortedList.get(j);
                context.write(new Text(entry.getKey()), new Text(entry.getValue() + ""));
            }

            context.write(new Text("Zero Data"), new Text(""));
            if (!exceptionMap.isEmpty()) {
                for (Entry<String, Double> entry : exceptionMap.entrySet()) {
                    context.write(new Text(entry.getKey()), new Text(entry.getValue() + ""));
                }
            } else {
                context.write(new Text("NONE"), new Text(""));
            }
        } else {
            context.write(new Text("No data available for analysis."), new Text(""));
        }
    }
}

